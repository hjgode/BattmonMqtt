#BattmonMqtt
- publish Mqtt periodically with battery level

##Original base
This is a workmanager demo for stay app alive or wake up the app periodically. In some ROMs, it may not be useful because the task manager of them is like the force stop operation in phone settings.
The foreground service is useful for all versions and ROMs.