package com.hjgode.BattmonMqtt;

import android.util.Log;

public class util {
    public static void LOG(String m){
        Log.d("WORKER",m);
    }
}
